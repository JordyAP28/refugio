
<?php $__env->startSection('contenido'); ?>
<h2>Contáctanos</h2>
        <p>
            Si tienes dudas, sugerencias o necesitas ayuda, no dudes en comunicarte con nosotros a través de los siguientes medios.
        </p>

        <section>
            <h3>Información de Contacto</h3>
            <ul>
                <li><strong>Teléfono:</strong> +1 234 567 890</li>
                <li><strong>Email:</strong> contacto@gestionrefugios.com</li>
                <li><strong>Dirección:</strong> Av. Central #456, Ciudad Refugio</li>
            </ul>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\Experimento\refugio\sisRefugio\resources\views/home/contacto.blade.php ENDPATH**/ ?>