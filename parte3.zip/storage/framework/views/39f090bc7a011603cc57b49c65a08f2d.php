<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Refugiados</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <h1>Listado de Refugiados</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Apellidos y Nombres</th>
                <th>Tipo Doc.</th>
                <th>Num. Doc.</th>
                <th>Nacionalidad</th>
                <th>Sexo</th>
                <th>Teléfono</th>
                <th>Email</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($per->id_persona); ?></td>
                    <td><?php echo e($per->apellido . ' ' . $per->nombre); ?></td>
                    <td><?php echo e($per->tipo_documento); ?></td>
                    <td><?php echo e($per->num_documento); ?></td>
                    <td><?php echo e($per->nacionalidad); ?></td>
                    <td><?php echo e($per->sexo); ?></td>
                    <td><?php echo e($per->telefono); ?></td>
                    <td><?php echo e($per->usuario_email ?: 'No asignado'); ?></td>
                    <td><?php echo e($per->estado); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\PC\Documents\Experimento\refugio\sisRefugio\resources\views/refugiado/pdf.blade.php ENDPATH**/ ?>