
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<center>
			<h3>Llene el formulario para poder registrarse en el refugio</h3>
		</center><br>
		<?php if(count($errors)>0): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li> <?php echo e($error); ?> </li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
	</div>
</div>

<?php echo Form::model($refugio,['method'=>'PATCH','route'=>['refugios.update',$refugio->id_refugio],'files'=>true]); ?>

<?php echo e(Form::token()); ?>


<div class="row">
	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="nombre">Nombres</label>
			<input type="text" name="nombre" required value="<?php echo e($persona->nombre); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="apellido">Apellidos</label>
			<input type="text" name="apellido" required value="<?php echo e($persona->apellido); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="tipo_documento">Tipo documento</label>
			<select name="tipo_documento" class="form-control">
				<?php if($persona->tipo_documento=='Cédula'): ?>
					<option value="Cédula" selected>Cédula</option>
					<option value="Pasaporte">Pasaporte</option>
				<?php else: ?>
					<option value="Cédula">Cédula</option>
					<option value="Pasaporte" selected>Pasaporte</option>
				<?php endif; ?>
			</select>
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="num_documento">Numero de documento</label>
			<input type="text" name="num_documento" value="<?php echo e($persona->num_documento); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="nacionalidad">Nacionalidad</label>
			<input type="text" name="nacionalidad" value="<?php echo e($persona->nacionalidad); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="foto_perfil">Foto de perfil</label>
			<input type="file" name="foto_perfil" class="form-control">
			<?php if(($persona->foto_perfil)!=""): ?>
			<center>
			<img src="<?php echo e(asset('imagenes/refugiados/'.$persona->foto_perfil)); ?>" height="100px" width="150px">
			</center>
			<?php endif; ?>
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="fecha_nacimiento">Fecha de nacimiento</label>
			<input type="date" name="fecha_nacimiento" value="<?php echo e($persona->fecha_nacimiento); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="sexo">Sexo</label>
			<select name="sexo" class="form-control">
				<?php if($persona->sexo=='Masculino'): ?>
					<option value="Masculino" selected>Masculino</option>
					<option value="Femenino">Femenino</option>
				<?php else: ?>
					<option value="Masculino">Masculino</option>
					<option value="Femenino" selected>Femenino</option>
				<?php endif; ?>
			</select>
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="direccion">Dirección</label>
			<input type="text" name="direccion" required value="<?php echo e($persona->direccion); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="email">Correo electronico</label>
			<input type="text" name="email" required value="<?php echo e($persona->email); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="telefono">Telefono</label>
			<input type="text" name="telefono" required value="<?php echo e($persona->telefono); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="tipo_sanguineo">Tipo sanguineo</label>
			<select name="tipo_sanguineo" id="tipo_sanguineo" class="form-control">
				<?php if($persona->tipo_sanguineo=='A+'): ?>
					<option value="A+" selected>A+</option>
				    <option value="A-">A-</option>
				    <option value="B+">B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-">O-</option>
				<?php elseif($persona->tipo_sanguineo=='A-'): ?>
					<option value="A+">A+</option>
				    <option value="A-" selected>A-</option>
				    <option value="B+">B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-">O-</option>
				<?php elseif($persona->tipo_sanguineo=='B+'): ?>
					<option value="A+">A+</option>
				    <option value="A-">A-</option>
				    <option value="B+" selected>B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-">O-</option>
				<?php elseif($persona->tipo_sanguineo=='B-'): ?>
					<option value="A+">A+</option>
				    <option value="A-">A-</option>
				    <option value="B+">B+</option>
				    <option value="B-" selected>B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-">O-</option>
				<?php elseif($persona->tipo_sanguineo=='AB+'): ?>
					<option value="A+">A+</option>
				    <option value="A-">A-</option>
				    <option value="B+">B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+" selected>AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-">O-</option>
				<?php elseif($persona->tipo_sanguineo=='AB-'): ?>
					<option value="A+">A+</option>
				    <option value="A-">A-</option>
				    <option value="B+">B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-" selected>AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-">O-</option>
				<?php elseif($persona->tipo_sanguineo=='O+'): ?>
					<option value="A+">A+</option>
				    <option value="A-">A-</option>
				    <option value="B+">B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+" selected>O+</option>
				    <option value="O-">O-</option>
				<?php else: ?>
					<option value="A+">A+</option>
				    <option value="A-">A-</option>
				    <option value="B+">B+</option>
				    <option value="B-">B-</option>
				    <option value="AB+">AB+</option>
				    <option value="AB-">AB-</option>
				    <option value="O+">O+</option>
				    <option value="O-" selected>O-</option>
				<?php endif; ?>
			</select>
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="estado">Estado del refugiado</label>
			<select name="estado" class="form-control">
				<?php if($persona->estado=='Activo'): ?>
					<option value="Activo" selected>Activo</option>
					<option value="Inactivo">Inactivo</option>
				<?php else: ?>
					<option value="Activo">Activo</option>
					<option value="Inactivo" selected>Inactivo</option>
				<?php endif; ?>
			</select>
		</div>
	</div>

	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<label for="discapacidad">Discapacidad</label>
			<textarea type="text" name="discapacidad"class="form-control"><?php echo e($persona->discapacidad); ?></textarea>
		</div>
	</div>

	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<label for="patologia">Patologia</label>
			<textarea type="text" name="patologia"class="form-control"><?php echo e($persona->patologia); ?></textarea>
		</div>
	</div>

	<div class="col-lg12 col-md-12 col-sm-12 col-xs-12">
		<center>
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<a href="<?php echo e(URL('refugiados')); ?>" class="btn btn-danger">Cancelar</a>
		</div>
		</center>
	</div>

</div>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\refugio\sisRefugio\resources\views/refugios/create.blade.php ENDPATH**/ ?>