
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<center><h3>Refugios</h3></center><br>
	</div>
</div>
<div class="row">
    <?php $__currentLoopData = $refugios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refugio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="card">
                <div class="card-header text-center" style="background-color: #333; color: white;">
                    <h5>Refugio: <?php echo e($refugio->nombre_refugio); ?></h5>
                </div>
                <div class="card-body">
                    <p><strong>Ubicación:</strong> <?php echo e($refugio->ubicacion); ?></p>
                    <p><strong>Capacidad máxima:</strong> <?php echo e($refugio->capacidad_maxima); ?> personas</p>
                    <p><strong>Capacidad actual:</strong> <?php echo e($refugio->capacidad_actual); ?> personas</p>
                    <div><?php echo $refugio->descripcion; ?></div> <!-- Interpreta el HTML -->
                    <button class="btn btn-info" onclick="location.href='<?php echo e(route('refugios.edit', $refugio->id_refugio)); ?>'">Quiero registrarme
                        </button>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\refugio\sisRefugio\resources\views/refugios/index.blade.php ENDPATH**/ ?>