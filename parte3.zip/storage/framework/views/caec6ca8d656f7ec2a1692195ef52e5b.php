
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
		<h3>Editar Refugio: <?php echo e($refugio->nombre_refugio); ?></h3>
		<?php if(count($errors)>0): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li> <?php echo e($error); ?> </li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
	</div>
</div>

<?php echo Form::model($refugio,['method'=>'PATCH','route'=>['refugio.update',$refugio->id_refugio],'files'=>true]); ?>

<?php echo e(Form::token()); ?>


<div class="row">
	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="nombre_refugio">Nombre</label>
			<input type="text" name="nombre_refugio" required value="<?php echo e($refugio->nombre_refugio); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="tipo_refugio">Tipo</label>
			<input type="text" name="tipo_refugio" required value="<?php echo e($refugio->tipo_refugio); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="direccion">Dirección</label>
			<input type="text" name="direccion" required value="<?php echo e($refugio->direccion); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<label for="ubicacion">Ubicacion</label>
			<input type="text" name="ubicacion" value="<?php echo e($refugio->ubicacion); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
		<div class="form-group">
			<label for="capacidad_maxima">Capacidad total</label>
			<input type="number" name="capacidad_maxima" required value="<?php echo e($refugio->capacidad_maxima); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
		<div class="form-group">
			<label for="capacidad_actual">Capacidad actual</label>
			<input type="number" name="capacidad_actual" required value="<?php echo e($refugio->capacidad_maxima); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="telefono">Telefono</label>
			<input type="text" name="telefono" required value="<?php echo e($refugio->telefono); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="contacto">Correo electronico</label>
			<input type="text" name="contacto" required value="<?php echo e($refugio->contacto); ?>" class="form-control">
		</div>
	</div>

	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="imagen">Imagen</label>
			<input type="file" name="imagen" class="form-control">
			<?php if(($refugio->imagen)!=""): ?>
			<center>
			<img src="<?php echo e(asset('imagenes/refugios/'.$refugio->imagen)); ?>" height="100px" width="150px">
			</center>
			<?php endif; ?>
		</div>
	</div>


	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<div class="form-group">
			<label for="estado">Estado del refugio</label>
			<select name="estado" class="form-control">
				<?php if($refugio->estado=='Disponible'): ?>
					<option value="Disponible" selected>Disponible</option>
					<option value="No disponible">No disponible</option>
				<?php else: ?>
					<option value="Disponible">Disponible</option>
					<option value="No disponible" selected>No disponible</option>
				<?php endif; ?>
			</select>
		</div>
	</div>

	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<label for="descripcion">Descripcion</label>
			<textarea name="descripcion" class="form-control" rows="5"><?php echo e($refugio->descripcion); ?></textarea>
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<label for="recursos_disponibles">Recursos</label>
			<textarea name="recursos_disponibles" class="form-control" rows="3"><?php echo e($refugio->recursos_disponibles); ?></textarea>
		</div>
	</div>


	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<a href="<?php echo e(URL('refugio')); ?>" class="btn btn-danger">Cancelar</a>

		</div>
	</div>

</div>

<script>
    tinymce.init({
        selector: 'textarea[name="descripcion"]', // Selecciona el campo específico
        plugins: 'lists', // Habilita el plugin de listas
        toolbar: 'undo redo | bold italic underline | bullist numlist | removeformat', // Opciones de herramientas
        menubar: false, // Oculta el menú superior (opcional)
        height: 300 // Ajusta la altura del editor
    });
</script>

<script>
    tinymce.init({
        selector: 'textarea[name="recursos_disponibles"]', // Selecciona el campo específico
        plugins: 'lists', // Habilita el plugin de listas
        toolbar: 'undo redo | bold italic underline | bullist numlist | removeformat', // Opciones de herramientas
        menubar: false, // Oculta el menú superior (opcional)
        height: 300 // Ajusta la altura del editor
    });
</script>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\refugio\sisRefugio\resources\views/refugio/edit.blade.php ENDPATH**/ ?>