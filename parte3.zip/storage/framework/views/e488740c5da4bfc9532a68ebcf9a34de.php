<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Refugios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <h1>Listado de Refugios</h1>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Tipo</th>
                <th>Dirección</th>
                <th>Capacidad</th>
                <th>Teléfono</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $refugios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ref->nombre_refugio); ?></td>
                    <td><?php echo e($ref->tipo_refugio); ?></td>
                    <td><?php echo e($ref->direccion); ?></td>
                    <td><?php echo e($ref->capacidad_maxima); ?>/<?php echo e($ref->capacidad_actual); ?></td>
                    <td><?php echo e($ref->telefono); ?></td>
                    <td><?php echo e($ref->estado); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\PC\Documents\Experimento\refugio\sisRefugio\resources\views/refugio/pdf.blade.php ENDPATH**/ ?>