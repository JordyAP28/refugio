
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">

	
	
	<h3>Listado de Refugiados <a href="<?php echo e(url('refugiados/create')); ?>"><button class="btn btn-success">Nuevo</button></a>
	<a href="<?php echo e(route('refugiado.exportPdfR')); ?>"><button class="btn btn-success">Exportar PDF</button></a>

	
	</h3>

		<?php echo $__env->make('refugiado.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>
</div>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead style="text-align: center;">
					<th>ID</th>
					<th>Apell. y nombres</th>
					<th>Foto</th>
					<th>Tipo doc.</th>
					<th>Num. doc.</th>
					<th>Nacionalidad</th>
					<th>Tipo san.</th>
					<th>Sexo</th>
					<th>Telefono</th>
					<th>Email</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>

				<?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($per->id_persona); ?></td>
					<td><?php echo e($per->apellido.' '.$per->nombre); ?></td>
					<td>
						<img src="<?php echo e(asset('imagenes/refugiados/'.$per->foto_perfil)); ?>" alt="<?php echo e($per->nombre); ?>" height="100px" width="100px" class="img-thumbnail">
					</td>
					<td><?php echo e($per->tipo_documento); ?></td>
					<td><?php echo e($per->num_documento); ?></td>
					<td><?php echo e($per->nacionalidad); ?></td>
					<td><?php echo e($per->tipo_sanguineo); ?></td>
					<td><?php echo e($per->sexo); ?></td>
					<td><?php echo e($per->telefono); ?></td>
					<td>
					    <?php if($per->usuario_email): ?>
					        <span><?php echo e($per->usuario_email); ?></span>
					    <?php else: ?>
					        <span>No asignado</span>
					    <?php endif; ?>
					</td>
					<td>
					    <?php if($per->estado == 'Activo'): ?>
					        <span class="badge badge-success"><?php echo e($per->estado); ?></span>
					    <?php else: ?>
					        <span class="badge badge-danger"><?php echo e($per->estado); ?></span>
					    <?php endif; ?>
					</td>

					<td>
						<button class="btn btn-info" onclick="location.href='<?php echo e(route('refugiados.edit', $per->id_persona)); ?>'">
						    <i class="fa fa-edit"></i> Editar
						</button>
						<a href="" data-target="#modal-delete-<?php echo e($per->id_persona); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
					</td>
				</tr>
				<?php echo $__env->make('refugiado.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</table>
		</div>
		<?php echo e($personas->render()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\Experimento\refugio\sisRefugio\resources\views/refugiado/index.blade.php ENDPATH**/ ?>