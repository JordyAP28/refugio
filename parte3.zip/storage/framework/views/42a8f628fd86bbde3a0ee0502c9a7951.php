<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desastres Naturales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h2>Principales Desastres Naturales en la Historia</h2>
    <table>
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Zona</th>
                <th>Impacto</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $desastres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desastre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($desastre['fecha']); ?></td>
                    <td><?php echo e($desastre['zona']); ?></td>
                    <td><?php echo e($desastre['impacto']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\PC\Documents\Experimento\refugio\sisRefugio\resources\views/pdf/desastres.blade.php ENDPATH**/ ?>