

<?php $__env->startSection('contenido'); ?>
<div class="container mt-4">
    <h1 class="mb-4">Foro de Publicaciones</h1>

    <!-- Mensajes de éxito o error -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Caja de nueva publicación -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Nueva Publicación</h5>
            <?php echo Form::open(['route' => 'publicaciones.store', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <?php echo Form::textarea('contenido', null, ['class' => 'form-control', 'rows' => 3, 'placeholder' => '¿Qué deseas compartir?', 'required' => true]); ?>

                </div>
                <div class="form-group mt-3">
                    <?php echo Form::submit('Publicar', ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

    <!-- Listado de publicaciones -->
    <h3 class="mb-4">Publicaciones Recientes</h3>
    <div class="publicaciones-list">
        <?php $__empty_1 = true; $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $public): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card mb-3">
                <div class="card-body">
                    <!-- Información del usuario y la fecha -->
                    <div class="d-flex justify-content-between">
                        <div>
                            <strong><?php echo e($public->usuario->username ?? 'Usuario desconocido'); ?></strong>
                            <small class="text-muted">
                                | <?php echo e(\Carbon\Carbon::parse($public->fecha_publicacion)->format('d/m/Y H:i')); ?>

                            </small>
                        </div>
                        <?php if($public->id_usuario === auth()->id()): ?>
                            <!-- Botones de acción (editar, eliminar) -->
                            <div>
                                <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal<?php echo e($public->id_publicacion); ?>">Editar</button>
                                <form action="<?php echo e(route('publicaciones.destroy', $public->id_publicacion)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta publicación?')">Eliminar</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Contenido de la publicación -->
                    <p><?php echo e($public->contenido); ?></p>
                </div>

                <!-- Respuestas (comentarios) -->
                <div class="card-footer">
                    <h5>Respuestas:</h5>
                    <?php $__currentLoopData = $public->respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="media mb-3">
                            <div class="media-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <strong><?php echo e($respuesta->usuario->username ?? 'Usuario desconocido'); ?></strong>
                                        <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($respuesta->fecha_respuesta)->format('d/m/Y H:i')); ?></small>
                                    </div>
                                    <?php if($respuesta->id_usuario === auth()->id()): ?>
                                        <!-- Botones de acción (editar, eliminar) -->
                                        <div>
                                            <!-- Editar respuesta -->
                                            <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModalRespuesta<?php echo e($respuesta->id_respuesta); ?>">Editar</button>
                                            <!-- Eliminar respuesta -->
                                            <form action="<?php echo e(route('respuestas.destroy', $respuesta->id_respuesta)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta respuesta?')">Eliminar</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <p><?php echo e($respuesta->contenido); ?></p>
                            </div>
                        </div>

                        <!-- Modal para editar respuesta -->
                        <div class="modal fade" id="editModalRespuesta<?php echo e($respuesta->id_respuesta); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalRespuestaLabel<?php echo e($respuesta->id_respuesta); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalRespuestaLabel<?php echo e($respuesta->id_respuesta); ?>">Editar Respuesta</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo Form::model($respuesta, ['route' => ['respuestas.update', $respuesta->id_respuesta], 'method' => 'PATCH']); ?>

                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <?php echo Form::textarea('contenido', $respuesta->contenido, ['class' => 'form-control', 'rows' => 3, 'required' => true]); ?>

                                            </div>
                                            <div class="form-group mt-3">
                                                <?php echo Form::submit('Actualizar Respuesta', ['class' => 'btn btn-primary']); ?>

                                            </div>
                                        <?php echo Form::close(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Formulario para añadir respuesta -->
                    <form action="<?php echo e(route('respuestas.store', $public->id_publicacion)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <textarea name="contenido" class="form-control" rows="3" placeholder="Escribe una respuesta..." required></textarea>
                        </div>
                        <div class="form-group mt-3">
                            <button type="submit" class="btn btn-success">Responder</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center">No hay publicaciones todavía. ¡Sé el primero en publicar algo!</p>
        <?php endif; ?>
    </div>

    <!-- Paginación -->
    <div class="mt-3">
        <?php echo e($publicaciones->links()); ?>

    </div>
    
</div>
<style>
    /* Estilo general de la página */
body {
    background-color: #f8f9fa; /* Fondo gris claro */
    font-family: 'Arial', sans-serif;
}

/* Título principal */
h1 {
    font-size: 2.5rem;
    font-weight: 700;
    color: #007bff;
}

/* Estilo para los mensajes de éxito */
.alert-success {
    background-color: #28a745;
    color: white;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Tarjetas de publicaciones */
.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.card-body {
    padding: 20px;
}

.card-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #6c757d;
}

/* Botones */
.btn {
    border-radius: 5px;
    padding: 10px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-primary, .btn-success {
    background-color: #007bff;
    border: none;
    color: white;
}

.btn-primary:hover, .btn-success:hover {
    background-color: #0056b3;
}

.btn-warning {
    background-color: #ffc107;
    color: #212529;
}

.btn-warning:hover {
    background-color: #e0a800;
}

.btn-danger {
    background-color: #dc3545;
    color: white;
}

.btn-danger:hover {
    background-color: #c82333;
}

.btn-sm {
    font-size: 0.875rem;
}

/* Respuestas (comentarios) */
.media {
    background-color: #f1f1f1;
    padding: 15px;
    border-radius: 8px;
}

.media-body {
    margin-left: 10px;
}

.media-body p {
    font-size: 1rem;
}

/* Espaciado y separación de elementos */
.mb-4, .mb-3 {
    margin-bottom: 30px;
}

.mt-3 {
    margin-top: 20px;
}

.text-muted {
    font-size: 0.875rem;
}

/* Modal */
.modal-content {
    border-radius: 10px;
}

.modal-header {
    background-color: #007bff;
    color: white;
    border-radius: 10px 10px 0 0;
}

.modal-body {
    padding: 20px;
}

/* Espaciado del formulario de publicación */
.form-group textarea {
    border-radius: 8px;
    padding: 10px;
    border: 1px solid #ccc;
    font-size: 1rem;
    width: 100%;
}

.form-group textarea:focus {
    border-color: #007bff;
    outline: none;
}

/* Listado de publicaciones */
.publicaciones-list {
    margin-top: 20px;
}

/* Paginación */
.pagination {
    justify-content: center;
    margin-top: 40px;
}

.pagination a, .pagination span {
    border-radius: 50%;
    padding: 8px 16px;
    font-size: 1rem;
    margin: 0 5px;
    color: #007bff;
    border: 1px solid #007bff;
    transition: all 0.3s ease;
}

.pagination a:hover, .pagination span:hover {
    background-color: #007bff;
    color: white;
    cursor: pointer;
}

/* Estilo para el área de texto de respuestas */
textarea[name="contenido"] {
    border-radius: 8px;
    padding: 10px;
    border: 1px solid #ccc;
    font-size: 1rem;
    width: 100%;
}

textarea[name="contenido"]:focus {
    border-color: #28a745;
    outline: none;
}

</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\sisRefugio\resources\views/publicaciones/index.blade.php ENDPATH**/ ?>